# Monitor Logs (Anonymized) Schema

Each JSON file contains:
- `timestamp` (string, ISO 8601, Z)
- `eventType` (string)
- `payload` (object; userAgent/headers/profile omitted if originally present)

Removed fields: `server_context`, `sessionId`.
Omitted events: `userProfile`.

Filenames: `<timestamp>-<eventType>-<seq>.json` grouped under `YYYY/MM/DD/`.
